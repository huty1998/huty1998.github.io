#define BOOST_TEST_MODULE Gource Test Suite
#include <boost/test/included/unit_test.hpp>
